function shinyLogo(){
    let logo = document.getElementById("logo")
    logo.classList.add("shiny")
};

function normalLogo(){
    let logo = document.getElementById("logo")
    logo.classList.remove("shiny")
    logo.classList.add("ynihs")
};

let logo = document.getElementById("logo")
